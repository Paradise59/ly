import torch
from litgpt.model import GPT
from torch.distributed._composable.fsdp import MixedPrecisionPolicy
from torch.distributed._composable.fsdp.fully_shard import fully_shard
from torch.distributed._tensor import Replicate, Shard
from torch.distributed.algorithms._checkpoint.checkpoint_wrapper import checkpoint_wrapper
from torch.distributed.device_mesh import DeviceMesh
from torch.distributed.tensor.parallel import (
    ColwiseParallel,
    PrepareModuleInput,
    RowwiseParallel,
    SequenceParallel,
    parallelize_module,
)

def parallelize(model: GPT, device_mesh: DeviceMesh) -> GPT:
    """Apply parallelisms and activation checkpointing to the model.

    NOTE: The passed-in model preferably should be on meta device. Otherwise,
    the model must fit on GPU or CPU memory.

    """

    dp_mesh = device_mesh["data_parallel"]
    tp_mesh = device_mesh["tensor_parallel"]

    # print(dp_mesh)
    # print(tp_mesh)
   

    if tp_mesh.size() > 1:
        # 1. Parallelize the first embedding and the last linear proj layer
        # 2. Parallelize the root norm layer over the sequence dim
        # 3. Shard the first transformer block's inputs

        # Parallelize the first embedding and the last linear out projection
        plan = {
            "transformer.wte": RowwiseParallel(input_layouts=Replicate()),
            "lm_head": ColwiseParallel(
                input_layouts=Shard(1),
                # Optional: Shard the output along the class dimension to compute the loss in parallel.
                # See `loss_parallel` in `train.py`
                output_layouts=Shard(-1),
                use_local_output=False,
            ),
            "transformer.ln_f": SequenceParallel(),
            "transformer.h.0": PrepareModuleInput(
                input_layouts=(Replicate(),  None,None,None,None),
                desired_input_layouts=(Shard(1),  None,None,None,None),
                use_local_output=True,
            ),
        }
        model = parallelize_module(model, tp_mesh, plan)
    
        n_head = model.transformer.h[0].attn.config.n_head // tp_mesh.size()
        n_query_groups = model.transformer.h[0].attn.config.n_query_groups // tp_mesh.size()
        # Parallelize each transformer block
        for block in model.transformer.h:
            plan = {
                "norm_1": SequenceParallel(),
                "attn": PrepareModuleInput(
                    input_layouts=(Shard(1), None,None,None,None),
                    desired_input_layouts=(Replicate(), None,None,None,None),
                ),
                "attn.wq": ColwiseParallel(),
                "attn.wk": ColwiseParallel(),
                "attn.wv": ColwiseParallel(),
                "attn.proj": RowwiseParallel(output_layouts=Shard(1)),
                
                "post_attention_norm": SequenceParallel(use_local_output=True),
                "norm_2": SequenceParallel(),
                "mlp": PrepareModuleInput(
                    input_layouts=(Shard(1),),
                    desired_input_layouts=(Replicate(),),
                ),
                "mlp.fc_1": ColwiseParallel(),
                "mlp.proj": RowwiseParallel(output_layouts=Shard(1)),
                "mlp.fc_2": ColwiseParallel(),    
                "post_mlp_norm": SequenceParallel(use_local_output=True),
            }
 
            # Adjust attention module to use the local number of heads
            attn_layer = block.attn
            attn_layer.config.n_head = n_head
            attn_layer.config.n_query_groups = n_query_groups

            # Apply the plan for the current transformer block
            parallelize_module(block, tp_mesh, plan)

    if dp_mesh.size() > 1:
        assert dp_mesh.ndim == 1  # Hybrid-sharding not supported

        # NOTE: Currently, the user is required to manually handle precision settings such as the `mp_policy` here
        # because the model parallel strategy does not respect all settings of `Fabric(precision=...)` at the moment.
        mp_policy = MixedPrecisionPolicy(param_dtype=torch.bfloat16, reduce_dtype=torch.float32)

        fsdp_config = {"mesh": dp_mesh, "mp_policy": mp_policy}
        for layer_id, block in enumerate(model.transformer['h']):
            # Apply activation checkpointing
            block = checkpoint_wrapper(block)
            # As an optimization, do not reshard after forward for the last
            # transformer block since FSDP would prefetch it immediately
            reshard_after_forward = int(layer_id) < len(model.transformer) - 1
            fully_shard(
                block,
                **fsdp_config,
                reshard_after_forward=reshard_after_forward,
            )
            model.transformer.h[layer_id] = block
        model = fully_shard(model, **fsdp_config)

    return model
 
